'use strict';
var fontendUrl = 'https://localhost:4200';
var backendUrl="http://localhost:9110";
var uploadPath = 'uploads';
var path = require('path');

module.exports = {
  app: {
    title: 'MEAN.JS',
    description: 'Full-Stack JavaScript with MongoDB, Express, AngularJS, and Node.js',
    keywords: 'mongodb, express, angularjs, node.js, mongoose, passport',
    googleAnalyticsTrackingID: process.env.GOOGLE_ANALYTICS_TRACKING_ID || 'GOOGLE_ANALYTICS_TRACKING_ID'
  },
  // twiAuthToken:"ACfbb089beeccdd1134ef2f7bec1fa4f79",
  // twiAccountSid:"ce364fdf54e8cd0d60ae6f7a0ca0e45f",
  // twiMlAppSid:"APb0cfbb6675f657fc7fb1694414295049",
  callerPhoneNumber:'+13853485087',
  twiAccountSid : "ACfbb089beeccdd1134ef2f7bec1fa4f79",
  twiAuthToken: "ce364fdf54e8cd0d60ae6f7a0ca0e45f",
  twiMlAppSid : "APb0cfbb6675f657fc7fb1694414295049",
  root: path.normalize(__dirname + '/../../..'),
  galleryPath:path.normalize(__dirname+'../../../public/uploads/gallery/'),
  avatarPath:path.normalize(__dirname+'../../../public/uploads/avatar/'),
  fontendUrl:fontendUrl,
  backendUrl:backendUrl,
  apiSiteUrl:'http://api.virt4real.com',
  adminEmail:'welcome@virt4real.com',
  emailAlertMemberOn:'thaiha1510@gmail.com',
  websiteName:'VIRT4REAL',
  adsPath:path.normalize(__dirname+'../../../public/uploads/ads/'),
  audioPath:path.normalize(__dirname+'../../../public/uploads/audio/'),
  galleryPath:path.normalize(__dirname+'../../../public/uploads/gallery/'),
  avatarBaseUrl:backendUrl+'/assets/images/img2.png',
  logoPath:path.normalize(__dirname+'../../../public/uploads/logo/'),
  ccbillLogPath:path.normalize(__dirname+'../../../public/storage/log/'),
  wallBaseUrl:backendUrl+'/assets/images/profile.png',
  uploadPath:path.normalize(__dirname+'../../../public/uploads/'),
  faviconPath:path.normalize(__dirname+'../../../public/uploads/favicon/'),
  db: {
    promise: global.Promise
  },
  port: process.env.PORT || 9110,
  host: process.env.HOST || 'localhost',
  // DOMAIN config should be set to the fully qualified application accessible
  // URL. For example: https://www.myapp.com (including port if required).
  domain: process.env.DOMAIN,
  // Session Cookie settings
  sessionCookie: {
    // session expiration is set by default to 24 hours
    maxAge: 24 * (60 * 60 * 1000),
    // httpOnly flag makes sure the cookie is only accessed
    // through the HTTP protocol and not JS/browser
    httpOnly: true,
    // secure cookie should be turned to true to provide additional
    // layer of security so that the cookie is set only when working
    // in HTTPS mode.
    secure: false
  },
  // sessionSecret should be changed for security measures and concerns
  sessionSecret: process.env.SESSION_SECRET || 'MEAN',
  // sessionKey is the cookie session name
  sessionKey: 'sessionId',
  sessionCollection: 'sessions',
  // Lusca config
  csrf: {
    csrf: false,
    csp: false,
    xframe: 'SAMEORIGIN',
    p3p: 'ABCDEF',
    xssProtection: true
  },
  logo: 'modules/core/client/img/brand/logo.png',
  favicon: 'modules/core/client/img/brand/favicon.ico',
  illegalUsernames: ['meanjs', 'administrator', 'password', 'admin', 'user',
    'unknown', 'anonymous', 'null', 'undefined', 'api'
  ],
  aws: {
    s3: {
      accessKeyId: process.env.S3_ACCESS_KEY_ID,
      secretAccessKey: process.env.S3_SECRET_ACCESS_KEY,
      bucket: process.env.S3_BUCKET
    }
  },
  uploads: {
    // Storage can be 'local' or 's3'
    storage: process.env.UPLOADS_STORAGE || 'local',
    profile: {
      image: {
        dest: './modules/users/client/img/profile/uploads/',
        limits: {
          fileSize: 1 * 1024 * 1024 // Max file size in bytes (1 MB)
        }
      }
    }
  },
  shared: {
    owasp: {
      allowPassphrases: true,
      maxLength: 128,
      minLength: 10,
      minPhraseLength: 20,
      minOptionalTestsToPass: 4
    }
  },
  mailer: {
		service: 'smtp', //smtp, mailgun,mailin,mandrill
		auth: {
			host: 'smtp.gmail.com',
			port: 587,
			secure: false,
			auth: {
				user: 'welcome@virt4real.com',
				pass: 'bqxswsxhbydyuozs '
			},
			//host: 'hoanvusolutions.com',
			//port: 25,
			//secure: false,
			//auth: {
			//     user: 'app+projects.hoanvusolutions.com',
			//    pass: 'Hoanvu2014!'
			//},  
			//tls: {
			//	rejectUnauthorized: true
			//}
		}
	},

};
